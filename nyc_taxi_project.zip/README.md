# NYC Taxi — Fare & Payment Predictor

Project contains:
- PySpark ETL (Bronze → Silver → Gold) for ~30M NYC taxi rows (S3)
- Regression: XGBoost fare prediction (tuned) with SHAP explainability
- Classification: payment type prediction (Logistic / GradientBoosting), SHAP
- Streamlit demo app (app.py)
- Saved models & artifacts in `models/` and `artifacts/`

How to run:
1. Unzip project
2. Install dependencies: `pip install -r requirements.txt`
3. Run Streamlit demo: `streamlit run app.py`
4. Models are in `models/` — update `app.py` if you want to load from S3.

